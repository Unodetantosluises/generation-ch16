package com.genration.ladm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoHolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
